import { useState, useEffect } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Globe, 
  Ship, 
  Plane, 
  Package, 
  CheckCircle, 
  Award, 
  Shield, 
  FileCheck,
  Menu,
  X,
  ArrowRight,
  Send,
  MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const products = [
    {
      name: 'Premium Rice',
      description: 'Basmati & Non-Basmati varieties sourced from trusted mills',
      varieties: ['Basmati Rice', 'Non-Basmati Rice', 'Raw Rice', 'Parboiled Rice', 'White Rice', 'Broken Rice'],
      packing: '5kg, 10kg, 25kg, 50kg bags',
      image: '/rice.jpg'
    },
    {
      name: 'Turmeric Finger',
      description: 'Premium quality Indian turmeric sourced directly from farmers',
      varieties: ['Natural Dried Turmeric', 'High Curcumin Content', 'Cleaned & Graded', 'Export Quality'],
      packing: '25kg PP/Jute bags',
      image: '/turmeric.jpg'
    },
    {
      name: 'Peanuts / Groundnut',
      description: 'High-quality peanuts suitable for food and oil industries',
      varieties: ['Bold Peanuts', 'Java Peanuts', 'Blanched Peanuts', 'Groundnut Kernels'],
      packing: 'As per buyer requirement',
      image: '/peanuts.jpg'
    },
    {
      name: 'Fresh Coconut',
      description: 'Fresh and processed coconuts from India',
      varieties: ['Fresh Coconut', 'Semi-Husked Coconut', 'Coconut Copra', 'Coconut Powder'],
      packing: 'Custom packaging available',
      image: '/coconut.jpg'
    },
    {
      name: 'Indian Spices',
      description: 'Wide range of spices with natural aroma and quality',
      varieties: ['Turmeric', 'Red Chilli', 'Black Pepper', 'Coriander Seeds', 'Cumin Seeds', 'Other Whole Spices'],
      packing: 'As per buyer requirement',
      image: '/spices.jpg'
    }
  ];

  const certifications = [
    'IEC (Import Export Code)',
    'MSME Registered',
    'APEDA Certified',
    'FASSI Compliant',
    'Phytosanitary & Fumigation'
  ];

  const qualityFeatures = [
    'Products sourced from verified suppliers',
    'Quality checked before shipment',
    'Export documents provided as per destination',
    'Packaging customized as per buyer needs'
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-wave flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div className="hidden sm:block">
                <h1 className={`font-bold text-lg leading-tight ${isScrolled ? 'text-[#0066CC]' : 'text-white'}`}>
                  BLUE WAVE
                </h1>
                <p className={`text-xs font-medium ${isScrolled ? 'text-[#00A8E8]' : 'text-white/80'}`}>
                  GLOBAL EXIM
                </p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {['Home', 'Products', 'About', 'Quality', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className={`text-sm font-medium transition-colors hover:text-[#00A8E8] ${
                    isScrolled ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <Button 
                onClick={() => scrollToSection('contact')}
                className="bg-wave hover:bg-wave-dark text-white px-6"
              >
                Get Quote
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`lg:hidden p-2 ${isScrolled ? 'text-gray-700' : 'text-white'}`}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t shadow-lg">
            <div className="px-4 py-4 space-y-2">
              {['Home', 'Products', 'About', 'Quality', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="block w-full text-left px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-[#0066CC] rounded-lg transition-colors"
                >
                  {item}
                </button>
              ))}
              <Button 
                onClick={() => scrollToSection('contact')}
                className="w-full bg-wave hover:bg-wave-dark text-white mt-4"
              >
                Get Quote
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center">
        <div className="absolute inset-0">
          <img 
            src="/hero-bg.jpg" 
            alt="Global Trade" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#003D7A]/90 via-[#0066CC]/80 to-transparent" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="max-w-2xl">
            <Badge className="bg-white/20 text-white border-0 mb-6 backdrop-blur-sm">
              <Globe className="w-4 h-4 mr-2" />
              Connecting Markets Worldwide
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              Premium Indian<br />
              <span className="text-[#00D4FF]">Agriculture Exports</span>
            </h1>
            <p className="text-lg sm:text-xl text-white/90 mb-8 leading-relaxed">
              Turmeric, Rice, Peanuts, Groundnut, Coconut & Spices — 
              Quality agricultural products exported globally with reliability and trust.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => scrollToSection('products')}
                className="bg-white text-[#0066CC] hover:bg-gray-100 px-8 py-6 text-lg font-semibold"
              >
                Explore Products
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button 
                onClick={() => scrollToSection('contact')}
                variant="outline"
                className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
              >
                <Phone className="w-5 h-5 mr-2" />
                Contact Us
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Ship, label: 'Sea Freight', value: 'Global Shipping' },
                { icon: Plane, label: 'Air Cargo', value: 'Express Delivery' },
                { icon: Package, label: 'Products', value: '5+ Categories' },
                { icon: Globe, label: 'Markets', value: 'Worldwide' },
              ].map((stat, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">{stat.value}</p>
                    <p className="text-white/70 text-sm">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 lg:py-28 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-[#0066CC] mb-4">Our Products</Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Premium Agricultural <span className="text-gradient">Exports</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We supply a wide range of high-quality Indian agricultural products 
              sourced from verified suppliers and trusted mills.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <Card key={index} className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300">
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-bold text-white">{product.name}</h3>
                  </div>
                </div>
                <CardContent className="p-6">
                  <p className="text-gray-600 mb-4">{product.description}</p>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-semibold text-gray-900 mb-2">Available Varieties:</p>
                      <div className="flex flex-wrap gap-2">
                        {product.varieties.slice(0, 4).map((variety, vIndex) => (
                          <span key={vIndex} className="text-xs bg-blue-50 text-[#0066CC] px-2 py-1 rounded">
                            {variety}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Package className="w-4 h-4" />
                      <span>{product.packing}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Important Note */}
          <div className="mt-12 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                <Shield className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h4 className="font-semibold text-amber-900 mb-1">Important Note</h4>
                <p className="text-amber-800">
                  Product specifications, packing, and prices are customized based on buyer requirements 
                  and destination country. Contact us for detailed quotations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="bg-blue-100 text-[#0066CC] mb-4">About Us</Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
                Your Trusted Partner in <span className="text-gradient">Global Trade</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Blue Wave Global Exim is an India-based exporter of quality agricultural products. 
                We focus on reliable sourcing, quality control, and timely delivery for global buyers.
              </p>
              <p className="text-gray-600 mb-8">
                With our strong network of verified suppliers and farmers across India, we ensure 
                that every product meets international standards. Our commitment to excellence has 
                made us a preferred choice for buyers worldwide.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  'Direct sourcing from farmers',
                  'Quality assurance at every step',
                  'Timely delivery commitment',
                  'Competitive pricing'
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-[#00A8E8]" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -inset-4 bg-wave/10 rounded-3xl transform rotate-3" />
              <div className="relative bg-gradient-to-br from-[#0066CC] to-[#00A8E8] rounded-2xl p-8 text-white">
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { value: '5+', label: 'Product Categories' },
                    { value: '100%', label: 'Quality Assured' },
                    { value: 'Global', label: 'Market Reach' },
                    { value: '24/7', label: 'Customer Support' },
                  ].map((stat, index) => (
                    <div key={index} className="text-center">
                      <p className="text-3xl sm:text-4xl font-bold text-[#00D4FF]">{stat.value}</p>
                      <p className="text-white/80 text-sm mt-1">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quality & Certifications Section */}
      <section id="quality" className="py-20 lg:py-28 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-white/10 text-white mb-4">Quality & Compliance</Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
              Certified for <span className="text-[#00D4FF]">Excellence</span>
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto">
              We maintain the highest standards of quality and compliance for international trade.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Certifications */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-3">
                <Award className="w-6 h-6 text-[#00D4FF]" />
                Our Certifications
              </h3>
              <div className="space-y-4">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-4 bg-white/5 rounded-xl p-4">
                    <div className="w-10 h-10 rounded-full bg-[#00A8E8]/20 flex items-center justify-center">
                      <FileCheck className="w-5 h-5 text-[#00D4FF]" />
                    </div>
                    <span className="text-gray-200">{cert}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quality Features */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-3">
                <Shield className="w-6 h-6 text-[#00D4FF]" />
                Quality Assurance
              </h3>
              <div className="space-y-4">
                {qualityFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start gap-4 bg-white/5 rounded-xl p-4">
                    <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    </div>
                    <span className="text-gray-200">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 lg:py-28 bg-wave">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-white/20 text-white mb-4">Contact Us</Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Let's Connect
            </h2>
            <p className="text-lg text-white/80 max-w-2xl mx-auto">
              Ready to import premium Indian agricultural products? Get in touch with us today.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Cards */}
            <Card className="border-0 shadow-xl">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">WhatsApp</h3>
                <p className="text-gray-600 mb-4">Chat with us directly</p>
                <a 
                  href="https://wa.me/919344974955" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#0066CC] font-semibold hover:underline"
                >
                  +91 93449 74955
                </a>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-6">
                  <Phone className="w-8 h-8 text-[#0066CC]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Phone</h3>
                <p className="text-gray-600 mb-4">Call us anytime</p>
                <a 
                  href="tel:+919344974955"
                  className="text-[#0066CC] font-semibold hover:underline"
                >
                  +91 93449 74955
                </a>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-6">
                  <Mail className="w-8 h-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Email</h3>
                <p className="text-gray-600 mb-4">Send us an email</p>
                <div className="space-y-1">
                  <a 
                    href="mailto:info@bluewaveglobalexim.com"
                    className="text-[#0066CC] font-semibold hover:underline block text-sm"
                  >
                    info@bluewaveglobalexim.com
                  </a>
                  <a 
                    href="mailto:sales@bluewaveglobalexim.com"
                    className="text-[#0066CC] font-semibold hover:underline block text-sm"
                  >
                    sales@bluewaveglobalexim.com
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Address & CTA */}
          <div className="mt-12 bg-white rounded-2xl p-8 lg:p-12">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <MapPin className="w-6 h-6 text-[#0066CC]" />
                  <h3 className="text-xl font-bold text-gray-900">Our Address</h3>
                </div>
                <p className="text-gray-600 text-lg leading-relaxed">
                  <strong className="text-gray-900">Blue Wave Global Exim</strong><br />
                  9, Gulam Yasin Street,<br />
                  Tirupattur - 635601,<br />
                  Tamil Nadu, India
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-end">
                <Button 
                  onClick={() => window.open('https://wa.me/919344974955', '_blank')}
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-6 text-lg"
                >
                  <Send className="w-5 h-5 mr-2" />
                  WhatsApp Us
                </Button>
                <Button 
                  onClick={() => window.location.href = 'mailto:info@bluewaveglobalexim.com'}
                  variant="outline"
                  className="border-[#0066CC] text-[#0066CC] hover:bg-blue-50 px-8 py-6 text-lg"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Send Email
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            {/* Company Info */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-full bg-wave flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">BLUE WAVE</h3>
                  <p className="text-xs text-[#00A8E8]">GLOBAL EXIM</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm">
                Premium Indian agricultural exports. Connecting markets worldwide with quality products.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                {['Home', 'Products', 'About', 'Quality', 'Contact'].map((link) => (
                  <li key={link}>
                    <button 
                      onClick={() => scrollToSection(link.toLowerCase())}
                      className="hover:text-white transition-colors"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Products */}
            <div>
              <h4 className="font-semibold mb-4">Products</h4>
              <ul className="space-y-2 text-gray-400">
                {['Rice', 'Turmeric', 'Peanuts', 'Coconut', 'Spices'].map((product) => (
                  <li key={product}>
                    <span className="hover:text-white transition-colors cursor-pointer">
                      {product}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  +91 93449 74955
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  info@bluewaveglobalexim.com
                </li>
                <li className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5" />
                  Tirupattur, Tamil Nadu, India
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>&copy; {new Date().getFullYear()} Blue Wave Global Exim. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
